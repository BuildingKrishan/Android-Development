package com.example.courseproject2

class courseinfo (val courseid: String, val coursetitle: String) {
    override fun toString(): String {
        return coursetitle
    }
}

data class noteinfo(var course: courseinfo? = null, var notetitle: String? = null, var note: String? = null)
//{
//    override fun toString(): String {
//        return notetitle + " -- " + note
//    }
//}

