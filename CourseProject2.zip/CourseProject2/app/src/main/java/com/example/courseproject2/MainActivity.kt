package com.example.courseproject2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner


class MainActivity : AppCompatActivity() {
    private var noteposition = POSITION_NOT_SET
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val dm= datamanager
        val spinner = findViewById<Spinner>(R.id.coursespinner)
        val adaptercourses = ArrayAdapter<courseinfo>(this,
            android.R.layout.simple_spinner_item, dm.courses.values.toList())
        adaptercourses.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adaptercourses
        noteposition = savedInstanceState?.getInt(NOTE_POSITION, POSITION_NOT_SET) ?:
        intent.getIntExtra(NOTE_POSITION, POSITION_NOT_SET)
        if (noteposition !=POSITION_NOT_SET)
        displaynote()
        else{
            datamanager.notes.add(noteinfo())
            noteposition=datamanager.notes.lastIndex
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState?.putInt(NOTE_POSITION, noteposition)
    }

    private fun displaynote() {
        val note = datamanager.notes[noteposition]
        val coursestitle = findViewById<EditText>(R.id.coursetitle)
        coursestitle.setText(note.notetitle)
        val coursesnote = findViewById<EditText>(R.id.coursenotes)
        coursesnote.setText(note.note)
        val courseposition = datamanager.courses.values.indexOf(note.course)
        val spinner = findViewById<Spinner>(R.id.coursespinner)
        spinner.setSelection(courseposition)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        return when (item.itemId) {
            R.id.action_settings -> true
            R.id.action_next -> {
                moveNext()

                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        if (noteposition >= datamanager.notes.lastIndex) {
            val menuItem = menu?.findItem(R.id.action_next)
            if (menuItem != null){
                menuItem.icon = getDrawable(R.drawable.ic_baseline_block_24)
                menuItem.isEnabled = false
            }
        }
        return super.onPrepareOptionsMenu(menu)
    }

    private fun moveNext() {
        ++noteposition
        displaynote()
        invalidateOptionsMenu()
    }

    override fun onPause() {
        super.onPause()
        saveNote()
    }

    private fun saveNote() {

        var note= datamanager.notes[noteposition]
        val coursenote = findViewById<EditText>(R.id.coursenotes)
        val title = findViewById<EditText>(R.id.coursetitle)
        note.notetitle = title.text.toString()
        note.note = coursenote.text.toString()
        val spinner = findViewById<Spinner>(R.id.coursespinner)
        note.course = spinner.selectedItem as courseinfo

    }
}