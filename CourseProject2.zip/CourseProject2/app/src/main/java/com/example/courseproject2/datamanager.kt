package com.example.courseproject2

import kotlin.collections.get as get1

object datamanager {
    val courses = HashMap<String, courseinfo>()
    val notes = ArrayList<noteinfo>()
    init {
        initializecourses()
        initializenotes()
    }

     fun initializenotes() {
       //  var course: courseinfo = courses.get1(0)
         var note = noteinfo(courses.get("AND100"), "Kotlin Lang", "Kotlin is a concise language with powerful Java Integration" )
         notes.add(note)
         note = noteinfo(courses.get("COL100"), "C++ Lang", "C++ is old language" )
         notes.add(note)
         note = noteinfo(courses.get("COL100"), "Python", "Python is easy, looks like a pseudocode" )
         notes.add(note)
         note = noteinfo(courses.get("COL300"), "OS Lang", " OS is very very tough to understand" )
         notes.add(note)
     }

    fun initializecourses() {
        var course = courseinfo ( courseid= "AND100", coursetitle=  "Android Development"  )
        courses.set(course.courseid, course)
        course = courseinfo ( courseid= "COL100", coursetitle=  "Intro to Programming"  )
        courses.set(course.courseid, course)
        course = courseinfo ( courseid= "ELL365", coursetitle=  "Embedded Programming"  )
        courses.set(course.courseid, course)
        course = courseinfo ( courseid= "COL300", coursetitle=  "Operating System"  )
        courses.set(course.courseid, course)}
}