package com.example.courseproject2

import android.R
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.ui.AppBarConfiguration
import com.example.courseproject2.databinding.ActivityNotelistactivityBinding
class notelistactivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityNotelistactivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityNotelistactivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
     //   setContentView(R.layout.)
        setSupportActionBar(binding.toolbar)


        binding.fab.setOnClickListener { view ->
            val activityintent = Intent(this, MainActivity::class.java)
            startActivity(activityintent)
        }
        val list = binding.notelistt
        list.adapter = ArrayAdapter(this, R.layout.simple_list_item_1,datamanager.notes)
        list.setOnItemClickListener{parent, view, position, id->
            val activityIntent = Intent(this, MainActivity::class.java)
            activityIntent.putExtra(NOTE_POSITION, position )
            startActivity(activityIntent)
        }
    }

    override fun onResume() {
        super.onResume()
        (binding.notelistt.adapter as ArrayAdapter<noteinfo>).notifyDataSetChanged()
    }
}